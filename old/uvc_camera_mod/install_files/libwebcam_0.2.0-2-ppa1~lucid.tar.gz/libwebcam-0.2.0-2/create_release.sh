#!/bin/sh
# parameters: 
# version = $1
# usage: ./create_release.sh version 

if [ $# -gt 0 ]; then 
  #create tmp release dir
  mkdir "/tmp/libwebcam-$1"
 
  #copy release data
  cp -r common /tmp/libwebcam-$1/.
  cp -r libwebcam /tmp/libwebcam-$1/.
  cp -r uvcdynctrl /tmp/libwebcam-$1/.
  cp CMakeLists.txt /tmp/libwebcam-$1/.
  cp README "/tmp/libwebcam-$1/."
 
  #remove svn data
  rm -rf /tmp/libwebcam-$1/common/.svn
  rm -rf /tmp/libwebcam-$1/common/include/.svn
  rm -rf /tmp/libwebcam-$1/common/build/.svn
  rm -rf /tmp/libwebcam-$1/libwebcam/.svn
  rm -rf /tmp/libwebcam-$1/libwebcam/pkgconfig/.svn
  rm -rf /tmp/libwebcam-$1/libwebcam/dynctrl/.svn
  rm -rf /tmp/libwebcam-$1/uvcdynctrl/.svn
  rm -rf /tmp/libwebcam-$1/uvcdynctrl/data/.svn
  rm -rf /tmp/libwebcam-$1/uvcdynctrl/data/046d/.svn
  rm -rf /tmp/libwebcam-$1/uvcdynctrl/udev/.svn
  rm -rf /tmp/libwebcam-$1/uvcdynctrl/udev/rules/.svn
  rm -rf /tmp/libwebcam-$1/uvcdynctrl/udev/scripts/.svn
 
  # get destination dir
  if [ $# -eq 2 ]; then
    dest="$2"
  else
    cd ..
    dest="`pwd`"
  fi
  
  # build source package
  cd /tmp
  tar -cf libwebcam-src-$1.tar libwebcam-$1
  gzip libwebcam-src-$1.tar
 
  # move to destination dir 
  mv libwebcam-src-$1.tar.gz ${dest}
 
  # remove tmp data
  rm -rf libwebcam-$1
  
  echo "Created libwebcam-src-$1.tar.gz in ${dest}"
else
  echo "$0:Error command arguments missing!"
  echo "Usage: $0 VERSION [DESTINATION]"
  echo "VERSION = x.x.x"
  echo "DESTINATION(optional) = /path/to/release_dir/"
fi

#
# libwebcam source package release script (version: 0.1): 
#    2010 - Paulo Assis <pj.assis@gmail.com>
#
