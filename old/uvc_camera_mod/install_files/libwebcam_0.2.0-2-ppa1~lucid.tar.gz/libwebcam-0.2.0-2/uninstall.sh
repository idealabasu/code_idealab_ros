#!/bin/sh
rm -rf /usr/local/lib/libwebcam.so* /usr/local/bin/uvcdynctrl* /etc/udev/rules.d/80-uvcdynctrl.rules /etc/udev/data /lib/udev/uvcdynctrl
