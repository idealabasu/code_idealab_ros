#!/bin/sh
xsltproc --output ../../Common/include/dynctrl-logitech.h include.xsl data/046d/logitech.xml
